export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { prompt, tool } = req.body || {};

    if (!prompt || typeof prompt !== "string") {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const geminiKey = process.env.GEMINI_API_KEY;
    const hfKey = process.env.HUGGINGFACE_API_KEY;
    const hfModel = process.env.HUGGINGFACE_MODEL || "Qwen/Qwen2.5-7B-Instruct";

    if (!geminiKey && !hfKey) {
      return res.status(500).json({
        error: "No AI provider is configured. Add GEMINI_API_KEY or HUGGINGFACE_API_KEY."
      });
    }

    const systemPrompt =
      "You are CreatorToolbox, an AI assistant for social media creators. " +
      "Give useful, concise, platform-friendly creator content. " +
      `The requested tool is: ${tool || "general"}.`;

    const fullPrompt = `${systemPrompt}\n\nUser request:\n${prompt}`;

    // 1. Primary provider: Gemini
    if (geminiKey) {
      try {
        const geminiResponse = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(geminiKey)}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              contents: [
                {
                  role: "user",
                  parts: [{ text: fullPrompt }]
                }
              ],
              generationConfig: {
                temperature: 0.7,
                maxOutputTokens: 1200
              }
            })
          }
        );

        const geminiData = await geminiResponse.json();

        if (geminiResponse.ok) {
          const result =
            geminiData?.candidates?.[0]?.content?.parts
              ?.map(part => part.text || "")
              .join("")
              .trim();

          if (result) {
            return res.status(200).json({
              result,
              provider: "gemini"
            });
          }
        }

        console.error("Gemini failed:", geminiData);
      } catch (error) {
        console.error("Gemini request error:", error);
      }
    }

    // 2. Backup provider: Hugging Face
    if (hfKey) {
      try {
        const hfResponse = await fetch(
          `https://router.huggingface.co/v1/chat/completions`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${hfKey}`
            },
            body: JSON.stringify({
              model: hfModel,
              messages: [
                {
                  role: "system",
                  content: systemPrompt
                },
                {
                  role: "user",
                  content: prompt
                }
              ],
              temperature: 0.7,
              max_tokens: 1200
            })
          }
        );

        const hfData = await hfResponse.json();

        if (hfResponse.ok) {
          const result =
            hfData?.choices?.[0]?.message?.content?.trim();

          if (result) {
            return res.status(200).json({
              result,
              provider: "huggingface"
            });
          }
        }

        console.error("Hugging Face failed:", hfData);
      } catch (error) {
        console.error("Hugging Face request error:", error);
      }
    }

    return res.status(502).json({
      error: "Both Gemini and Hugging Face failed."
    });
  } catch (error) {
    console.error("Generate API error:", error);

    return res.status(500).json({
      error: "Generation failed."
    });
  }
}
