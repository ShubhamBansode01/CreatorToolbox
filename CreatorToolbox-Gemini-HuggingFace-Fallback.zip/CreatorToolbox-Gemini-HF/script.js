const promptInput = document.getElementById("prompt");
const toolInput = document.getElementById("tool");
const generateButton = document.getElementById("generate");
const provider = document.getElementById("provider");
const result = document.getElementById("result");

generateButton.addEventListener("click", async () => {
  const prompt = promptInput.value.trim();
  const tool = toolInput.value;

  if (!prompt) {
    result.textContent = "Please enter a prompt.";
    return;
  }

  generateButton.disabled = true;
  generateButton.textContent = "Generating...";
  provider.textContent = "";
  result.textContent = "";

  try {
    const response = await fetch("/api/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        prompt,
        tool
      })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Request failed");
    }

    result.textContent = data.result || "No result returned.";

    if (data.provider === "gemini") {
      provider.textContent = "Generated with Gemini";
    } else if (data.provider === "huggingface") {
      provider.textContent = "Gemini unavailable · Generated with Hugging Face";
    }
  } catch (error) {
    result.textContent = error.message || "Something went wrong.";
  } finally {
    generateButton.disabled = false;
    generateButton.textContent = "Generate";
  }
});
