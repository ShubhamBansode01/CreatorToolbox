# CreatorToolbox

Vercel-ready AI generation setup with:

1. Gemini as the primary provider
2. Hugging Face as an automatic fallback

## Environment variables

Add these in Vercel:

GEMINI_API_KEY=your_gemini_key
HUGGINGFACE_API_KEY=your_huggingface_key

Optional:

HUGGINGFACE_MODEL=Qwen/Qwen2.5-7B-Instruct

The API keys are only used by `api/generate.js` and are never placed in frontend JavaScript.

## Request

The frontend sends:

POST /api/generate

```json
{
  "prompt": "Write a 30 second reel script about discipline",
  "tool": "script"
}
```

## Fallback behavior

Gemini is attempted first.

If Gemini is unavailable, returns an error, or produces no usable text, Hugging Face is attempted.

If both fail, the API returns HTTP 502.
